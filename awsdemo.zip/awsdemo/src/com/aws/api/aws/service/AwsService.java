package com.aws.api.aws.service;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.Region;
import com.aws.api.aws.constant.AWMconstant;
import com.fujitsu.cn.fnst.webservice.frame.util.http.ProxySetting;

@Service
@Transactional
public class AwsService {

	public String UploadIMG(MultipartFile uploadFile) {
		// TODO Auto-generated method stub
//		获得uuid
		String uuid = UUID.randomUUID().toString().replace("-", "");
		
//		System.out.println(uuid);
//		更改图片名
		String oldFileName = uploadFile.getOriginalFilename();
		int lastIndexOfDot = oldFileName.lastIndexOf(".");
		String subfix = lastIndexOfDot >= 0 ? oldFileName.substring(lastIndexOfDot):".png";
		String newFileName = uuid + subfix;
		
//		存储本地所在位置,若没有则新建
		String localPath = "/images/portrait";
		
		File localFile = new File(localPath,newFileName);
		if (!localFile.exists()) {
			localFile.mkdirs();
		}
		
		try {
			uploadFile.transferTo(localFile);
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			AWSCredentials credentials = new BasicAWSCredentials(AWMconstant.AWM_ACCESS_ID, AWMconstant.AWM_SECRET_KEY);
			
//			设置链接超时时间和网络代理
			ClientConfiguration config = new ClientConfiguration();
			config.setConnectionTimeout(7*60*1000);
			ProxySetting proxySetting = ProxySetting.getInstance();
			if (proxySetting.isEnable()) {
				config.setProxyHost(proxySetting.getHost());
				config.setProxyPort(proxySetting.getPort());
			}
//			config.setProxyHost("http://10.167.196.113");
//			config.setProxyPort(8080);
			
//			创建S3客户端对象
			AmazonS3Client s3Client = new AmazonS3Client(credentials,config);
//			设置区域为东京
			Region region = Region.valueOf("AP_Tokyo");
			s3Client.setRegion(region.toAWSRegion());
			
			File file = new File(localPath+File.separator+newFileName);
			String keyvalue = "/test/img/"+newFileName;
			System.out.println("key:"+keyvalue);
			
			PutObjectRequest putObjectRequest = new PutObjectRequest(AWMconstant.BUCKET_NAME, keyvalue, file);
			putObjectRequest.withCannedAcl(CannedAccessControlList.PublicRead);
			s3Client.putObject(putObjectRequest);
			
			GeneratePresignedUrlRequest urlRequest = new GeneratePresignedUrlRequest(AWMconstant.BUCKET_NAME, keyvalue);
			URL url = s3Client.generatePresignedUrl(urlRequest);
			return url.toString();
			
		}catch (AmazonServiceException e) {
			// TODO: handle exception
			System.out.println("S3 save error1!");
		}catch (AmazonClientException ase) {
			// TODO: handle exception
			String errMsg = "AmazonClientException Error Message: " + 
			ase.getMessage() + ", BucketName: " + AWMconstant.BUCKET_NAME;
			System.out.println("S3保存失敗 " + errMsg+"\n"+ ase);
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("S3 save error3!");
		}
		finally {
			// TODO: handle finally clause
			localFile.delete();
		}
		
		
		return null;
	}
	

}
