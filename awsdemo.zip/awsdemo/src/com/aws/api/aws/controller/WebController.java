package com.aws.api.aws.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.aws.api.aws.service.AwsService;

@Controller
public class WebController {

	@Autowired
	private AwsService s3service;
	
	@RequestMapping(value="/hello",method=RequestMethod.GET)
	@ResponseBody
	public String HelloWorld() {
		return "hahah";
	}
	
	@RequestMapping(value="/img",method=RequestMethod.POST)
	@ResponseBody
	public String UploadImage(@RequestParam("uploadFile") MultipartFile uploadFile) {
		String imgURL = s3service.UploadIMG(uploadFile);
		return imgURL;
	}
}
