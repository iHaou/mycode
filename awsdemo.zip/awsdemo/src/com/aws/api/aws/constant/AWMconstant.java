package com.aws.api.aws.constant;

/**
 * AWM 相关的常量
 * @author lihao.fnst
 *
 */
public class AWMconstant {
	public static final String AWM_ACCESS_ID = "AKIAJ3TP5MBAH7FDKPLA";
	public static final String AWM_SECRET_KEY = "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";
	public static final String BUCKET_NAME = "transportationtest";
}
